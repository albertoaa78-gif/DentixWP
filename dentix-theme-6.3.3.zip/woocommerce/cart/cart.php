<?php
/**
 * cart/cart.php — Cesta "Anti-Interferencias" Dentix
 */
defined('ABSPATH') || exit;
get_header();
dentix_breadcrumb();
?>

<div class="page-content-wrap" style="max-width:1440px !important;">
    <div class="dentix-custom-cart-container">
        <header class="cart-header-main">
            <h1>Cesta de Productos</h1>
            <p>Revisa tu selección médica antes de proceder al pago.</p>
        </header>

        <?php wc_print_notices(); ?>

        <form class="woocommerce-cart-form" action="<?php echo esc_url(wc_get_cart_url()); ?>" method="post">
            <div class="medical-cart-grid">
                
                <div class="medical-cart-list">
                    <?php foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) :
                        $_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
                        if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 ) : ?>
                            
                            <div class="medical-cart-card">
                                <div class="m-card-img"><?php echo $_product->get_image(); ?></div>
                                <div class="m-card-info">
                                    <span class="m-tag">Producto Dentix</span>
                                    <h3><?php echo apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ); ?></h3>
                                    <p class="m-price">Precio unitario: <?php echo WC()->cart->get_product_price( $_product ); ?></p>
                                </div>
                                <div class="m-card-qty">
                                    <label>Cant.</label>
                                    <?php woocommerce_quantity_input( array( 'input_name' => "cart[{$cart_item_key}][qty]", 'input_value' => $cart_item['quantity'] ) ); ?>
                                </div>
                                <div class="m-card-subtotal">
                                    <label>Subtotal</label>
                                    <span><?php echo WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ); ?></span>
                                </div>
                                <div class="m-card-remove">
                                    <?php echo apply_filters( 'woocommerce_cart_item_remove_link', sprintf( '<a href="%s" class="m-remove">✕</a>', esc_url( wc_get_cart_remove_url( $cart_item_key ) ) ), $cart_item_key ); ?>
                                </div>
                            </div>

                        <?php endif; endforeach; ?>

                    <div class="m-cart-actions">
                        <?php if ( wc_coupons_enabled() ) { ?>
                            <div class="m-coupon">
                                <input type="text" name="coupon_code" placeholder="Código de descuento">
                                <button type="submit" name="apply_coupon">Validar</button>
                            </div>
                        <?php } ?>
                        <button type="submit" name="update_cart" class="m-update-btn">Actualizar Carrito</button>
                        <?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
                    </div>
                </div>

                <aside class="medical-summary-sidebar">
                    <div class="m-summary-box">
                        <h2>Resumen del pedido</h2>
                        <div class="m-totals-table">
                            <?php woocommerce_cart_totals(); ?>
                        </div>
                        <a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="m-checkout-btn">
                            Finalizar Compra
                        </a>
                        <div class="m-secure-tag">🔒 Pago seguro procesado por Dentix</div>
                    </div>
                </aside>

            </div>
        </form>
    </div>
</div>

<?php get_footer(); ?>
