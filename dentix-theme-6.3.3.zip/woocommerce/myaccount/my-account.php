<?php
/**
 * myaccount/my-account.php — Dashboard Médico Dentix
 */
defined('ABSPATH') || exit;
get_header();
dentix_breadcrumb();
?>

<div class="page-content-wrap dashboard-wide">
    <div class="medical-dashboard">
        <aside class="medical-sidebar">
            <div class="patient-profile">
                <div class="patient-avatar"><?php echo substr(wp_get_current_user()->display_name, 0, 1); ?></div>
                <div class="patient-info">
                    <span class="p-name"><?php echo esc_html(wp_get_current_user()->display_name); ?></span>
                    <span class="p-status">Paciente Verificado</span>
                </div>
            </div>
            
            <nav class="medical-nav">
                <?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : 
                    $url = wc_get_account_endpoint_url( $endpoint );
                    $is_active = (WC()->query->get_current_endpoint() === $endpoint || ($endpoint === 'dashboard' && !WC()->query->get_current_endpoint()));
                ?>
                    <a href="<?php echo esc_url($url); ?>" class="med-nav-link <?php echo $is_active ? 'is-active' : ''; ?>">
                        <span class="med-icon">
                            <?php if($endpoint == 'dashboard'): ?>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/></svg>
                            <?php elseif($endpoint == 'orders'): ?>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
                            <?php elseif($endpoint == 'edit-address'): ?>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
                            <?php elseif($endpoint == 'edit-account'): ?>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
                            <?php else: ?>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M10.09 15.59L11.5 17l5-5-5-5-1.41 1.41L12.67 11H3v2h9.67l-2.58 2.59zM19 3H5c-1.11 0-2 .9-2 2v4h2V5h14v14H5v-4H3v4c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/></svg>
                            <?php endif; ?>
                        </span>
                        <span class="med-label"><?php echo esc_html($label); ?></span>
                    </a>
                <?php endforeach; ?>
            </nav>
        </aside>

        <main class="medical-content">
            <div class="medical-card">
                <?php do_action( 'woocommerce_account_content' ); ?>
            </div>
        </main>
    </div>
</div>

<?php get_footer(); ?>

